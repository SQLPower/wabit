# $Id: buildJdk16.sh 48 2007-12-02 10:42:19Z jhyde $
# Called recursively from 'ant release' to build the files which can only be
# built under JDK 1.6.

# Change the following line to point to your JDK 1.6 home.
export JAVA_HOME=/usr/local/jdk1.6.0_01
export PATH=$JAVA_HOME/bin:$PATH
ant compile.java

# End buildJdk16.sh
