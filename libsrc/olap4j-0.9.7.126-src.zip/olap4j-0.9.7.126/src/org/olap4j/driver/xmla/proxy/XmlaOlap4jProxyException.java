/*
// $Id: XmlaOlap4jProxyException.java 126 2008-11-02 07:54:05Z jhyde $
// This software is subject to the terms of the Common Public License
// Agreement, available at the following URL:
// http://www.opensource.org/licenses/cpl.html.
// Copyright (C) 2007-2008 Julian Hyde
// All Rights Reserved.
// You must accept the terms of that agreement to use this software.
*/
package org.olap4j.driver.xmla.proxy;

/**
 * Gets thrown whenever an exception is encountered during the querying
 * of an XmlaOlap4jProxy subclass.
 *
 * @author Luc Boudreau
 * @version $Id: XmlaOlap4jProxyException.java 126 2008-11-02 07:54:05Z jhyde $
 */
public class XmlaOlap4jProxyException extends Exception {
    private static final long serialVersionUID = 1729906649527317997L;
    public XmlaOlap4jProxyException(String message, Throwable cause) {
        super(message, cause);
    }
}

// End XmlaOlap4jProxyException.java