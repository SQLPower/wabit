/*
// $Id: Named.java 125 2008-11-02 07:43:12Z jhyde $
// This software is subject to the terms of the Common Public License
// Agreement, available at the following URL:
// http://www.opensource.org/licenses/cpl.html.
// Copyright (C) 2007-2008 Julian Hyde
// All Rights Reserved.
// You must accept the terms of that agreement to use this software.
*/
package org.olap4j.impl;

/**
 * Interface which describes an object which has a name, for the purposes of
 * creating an implementation, {@link NamedListImpl} of
 * {@link org.olap4j.metadata.NamedList} which works on such objects.
 *
 * @author jhyde
 * @version $Id: Named.java 125 2008-11-02 07:43:12Z jhyde $
 * @since May 23, 2007
 */
public interface Named {
    /**
     * Returns the name of this object.
     *
     * @return name of this object
     */
    String getName();
}

// End Named.java
