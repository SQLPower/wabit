This is a source, binary or data distribution of Mondrian,
an OLAP Engine written in Java.

This code is released under the terms of the Common Public
License (CPL); see LICENSE.html.

For installation instructions, see doc/install.html
(http://mondrian.pentaho.org/documentation/installation.php).

The version is described in VERSION.txt.

Home page: http://mondrian.pentaho.org
Project home: http://sourceforge.net/projects/mondrian/
Email: jhyde@pentaho.com
